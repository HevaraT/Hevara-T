import React, { useState } from 'react';
import { Mail, Phone, MapPin, Star, ChevronRight, Menu, X } from 'lucide-react';

export default function HevaraTravelWebsite() {
  const [currentPage, setCurrentPage] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    destination: '',
    message: ''
  });

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    alert(`Thank you, ${formData.name}! We'll contact you soon about your ${formData.destination || 'holiday'}.`);
    setFormData({ name: '', email: '', phone: '', destination: '', message: '' });
  };

  const deals = [
    {
      id: 1,
      title: 'Bali Family Escape',
      image: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      nights: '7 nights',
      resort: '5★ beachfront resort',
      price: '£899',
      description: 'Experience pristine beaches, rice terraces and world-class hospitality. Perfect for families with kids clubs and water sports.'
    },
    {
      id: 2,
      title: 'Dubai Luxury Experience',
      image: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      nights: '5 nights',
      resort: '5★ downtown luxury',
      price: '£1,299',
      description: 'Iconic skyline views, premium shopping and desert safaris. All-inclusive with spa access and fine dining experiences.'
    },
    {
      id: 3,
      title: 'Santorini Honeymoon',
      image: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      nights: '6 nights',
      resort: '5★ cliffside suites',
      price: '£1,199',
      description: 'Romantic sunsets, volcanic beaches and exceptional local wine. Private terraces with Aegean Sea views included.'
    },
    {
      id: 4,
      title: 'Lapland Winter Magic',
      image: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
      nights: '4 nights',
      resort: 'Glass igloo or log cabin',
      price: '£749',
      description: 'Northern lights, husky sledding and meet Santa. Winter wonderland experience from December to February.'
    }
  ];

  const destinations = [
    { name: 'Bali', description: 'Tropical paradise with culture, beaches and adventure', icon: '🏝️' },
    { name: 'Dubai', description: 'Luxury shopping, modern architecture and desert adventures', icon: '🏙️' },
    { name: 'Santorini', description: 'Greek island romance with stunning sunsets and Mediterranean charm', icon: '🌅' },
    { name: 'Thailand', description: 'Ancient temples, street food and island hopping experiences', icon: '🏯' },
    { name: 'Australia', description: 'Outback, Great Barrier Reef and unique wildlife encounters', icon: '🦘' },
    { name: 'Lapland', description: 'Arctic adventures, northern lights and winter magic', icon: '❄️' }
  ];

  const navigationItems = [
    { label: 'Home', id: 'home' },
    { label: 'Destinations', id: 'destinations' },
    { label: 'Travel Deals', id: 'deals' },
    { label: 'Book', id: 'book' },
    { label: 'About', id: 'about' },
    { label: 'Contact', id: 'contact' }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setCurrentPage('home')}>
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-teal-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">H</span>
              </div>
              <span className="text-xl font-semibold text-gray-900">Hevara Travel</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              {navigationItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`text-sm font-medium transition ${
                    currentPage === item.id
                      ? 'text-blue-600 border-b-2 border-blue-600 pb-1'
                      : 'text-gray-700 hover:text-gray-900'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="md:hidden pb-4 flex flex-col gap-2">
              {navigationItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className="text-left px-4 py-2 text-gray-700 hover:bg-gray-100 rounded"
                >
                  {item.label}
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Home Page */}
        {currentPage === 'home' && (
          <div className="space-y-16">
            {/* Hero */}
            <section className="relative h-96 md:h-[500px] rounded-2xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-teal-500 opacity-80"></div>
              <div className="absolute inset-0 flex flex-col justify-center items-start px-8 md:px-16 text-white">
                <h1 className="text-4xl md:text-5xl font-bold mb-4">Explore • Dream • Discover</h1>
                <p className="text-lg md:text-xl mb-8 max-w-2xl">Curated travel experiences tailored to you. From luxury escapes to family adventures, we design the perfect journey.</p>
                <button
                  onClick={() => setCurrentPage('book')}
                  className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition flex items-center gap-2"
                >
                  Plan Your Trip <ChevronRight size={20} />
                </button>
              </div>
            </section>

            {/* Featured Deals */}
            <section>
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Travel Deals</h2>
                <p className="text-gray-600">Handpicked packages designed for unforgettable experiences</p>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {deals.map(deal => (
                  <div key={deal.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition">
                    <div className="h-48" style={{ background: deal.image }}></div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{deal.title}</h3>
                      <p className="text-gray-600 text-sm mb-4">{deal.description}</p>
                      <div className="flex justify-between items-center mb-4">
                        <div className="text-sm text-gray-500">
                          <div>{deal.nights}</div>
                          <div>{deal.resort}</div>
                        </div>
                        <div className="text-2xl font-bold text-blue-600">From {deal.price}</div>
                      </div>
                      <button
                        onClick={() => setCurrentPage('book')}
                        className="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition"
                      >
                        View Deal
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Why Book With Us */}
            <section className="bg-gray-50 rounded-2xl p-8 md:p-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Why Book With Hevara Travel</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl mx-auto mb-4">✓</div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Expert Curation</h3>
                  <p className="text-gray-600">We personally select every destination and experience to ensure exceptional quality.</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl mx-auto mb-4">✓</div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Personal Planning</h3>
                  <p className="text-gray-600">Our travel experts work with you to tailor every detail to your preferences and budget.</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl mx-auto mb-4">✓</div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Peace of Mind</h3>
                  <p className="text-gray-600">Full ATOL and ABTA protection on all bookings, plus 24/7 customer support.</p>
                </div>
              </div>
            </section>

            {/* Testimonials */}
            <section>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">What Travellers Say</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {[
                  { name: 'Sarah & James', text: 'The Bali trip exceeded all expectations. Every detail was perfect, and the personal touch made it truly special.', stars: 5 },
                  { name: 'Emily', text: 'My honeymoon in Santorini was absolutely magical thanks to Hevara Travel. Highly recommended!', stars: 5 },
                  { name: 'Michael', text: 'Great service, great value, and amazing experiences. Will definitely book again for our next family holiday.', stars: 5 },
                  { name: 'Lisa', text: 'The northern lights trip with my kids was unforgettable. Professional, knowledgeable and genuinely helpful.', stars: 5 }
                ].map((review, idx) => (
                  <div key={idx} className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                    <div className="flex mb-2">
                      {[...Array(review.stars)].map((_, i) => (
                        <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-gray-700 mb-4">"{review.text}"</p>
                    <p className="font-semibold text-gray-900">{review.name}</p>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {/* Destinations Page */}
        {currentPage === 'destinations' && (
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Explore Our Destinations</h1>
              <p className="text-gray-600">Discover amazing places around the world, curated for unforgettable travel experiences</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {destinations.map((dest, idx) => (
                <div key={idx} className="bg-white rounded-xl border border-gray-200 p-8 hover:shadow-lg transition text-center">
                  <div className="text-5xl mb-4">{dest.icon}</div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{dest.name}</h3>
                  <p className="text-gray-600">{dest.description}</p>
                  <button
                    onClick={() => setCurrentPage('book')}
                    className="mt-6 text-blue-600 font-semibold hover:text-blue-700 flex items-center justify-center gap-2 mx-auto"
                  >
                    Explore <ChevronRight size={18} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Travel Deals Page */}
        {currentPage === 'deals' && (
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Exclusive Travel Deals</h1>
              <p className="text-gray-600">Limited-time packages with exceptional value and unforgettable experiences</p>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              {deals.map(deal => (
                <div key={deal.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition">
                  <div className="h-64" style={{ background: deal.image }}></div>
                  <div className="p-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">{deal.title}</h3>
                    <p className="text-gray-600 mb-6">{deal.description}</p>
                    <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                      <div>
                        <p className="text-sm text-gray-500">Duration</p>
                        <p className="font-semibold">{deal.nights}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Accommodation</p>
                        <p className="font-semibold">5★</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">From</p>
                        <p className="font-semibold text-blue-600 text-lg">{deal.price}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setCurrentPage('book')}
                      className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
                    >
                      Book Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Book/Enquiry Page */}
        {currentPage === 'book' && (
          <div className="max-w-2xl mx-auto space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Plan Your Trip</h1>
              <p className="text-gray-600">Tell us about your dream holiday and we'll create the perfect itinerary for you</p>
            </div>
            <form onSubmit={handleFormSubmit} className="bg-white rounded-xl border border-gray-200 p-8 space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Your Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleFormChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  placeholder="John Smith"
                />
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleFormChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                    placeholder="+44 7741 326960"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Interested Destination</label>
                <select
                  name="destination"
                  value={formData.destination}
                  onChange={handleFormChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="">Select a destination...</option>
                  {destinations.map(dest => (
                    <option key={dest.name} value={dest.name}>{dest.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Tell Us About Your Dream Holiday</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleFormChange}
                  rows="5"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  placeholder="When are you thinking? Any specific requirements? Budget in mind?"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
              >
                Send Enquiry
              </button>
            </form>
          </div>
        )}

        {/* About Page */}
        {currentPage === 'about' && (
          <div className="max-w-4xl mx-auto space-y-12">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-4">About Hevara Travel</h1>
              <p className="text-lg text-gray-600">We believe travel should be an art form — carefully crafted, personally tailored, and unforgettably remarkable.</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
                <p className="text-gray-600">To create exceptional travel experiences that inspire, delight and transform. We work tirelessly to design journeys that feel personal, authentic and stress-free.</p>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Values</h2>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> Expert knowledge and genuine passion for travel</li>
                  <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> Personal attention and custom solutions</li>
                  <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> Integrity and transparency in all dealings</li>
                  <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> Commitment to customer satisfaction and peace of mind</li>
                </ul>
              </div>
            </div>

            <div className="bg-blue-50 rounded-xl p-8 border border-blue-200">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Regulated & Protected</h2>
              <p className="text-gray-700 mb-4">Hevara Travel is an independent travel agent trading on behalf of InteleTravel Ltd, a Member of ABTA (Association of British Travel Agents). When you book a package holiday that includes flights through us, your booking is ATOL protected — you will receive an ATOL Certificate confirming what is covered and who is responsible for delivering it.</p>
              <p className="text-gray-700">This protection gives you financial peace of mind and access to ABTA's dispute resolution service should any issues arise.</p>
            </div>
          </div>
        )}

        {/* Contact Page */}
        {currentPage === 'contact' && (
          <div className="max-w-4xl mx-auto space-y-12">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Get In Touch</h1>
              <p className="text-gray-600">Have questions? We're here to help. Contact us today to start planning your next adventure.</p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
                <Phone className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Phone</h3>
                <a href="tel:+447741326960" className="text-blue-600 hover:text-blue-700">+44 7741 326960</a>
              </div>
              <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
                <Mail className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Email</h3>
                <a href="mailto:hello@hevaratravel.co.uk" className="text-blue-600 hover:text-blue-700">hello@hevaratravel.co.uk</a>
              </div>
              <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
                <MapPin className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Based In</h3>
                <p className="text-gray-600">United Kingdom</p>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Send us a message</h2>
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleFormChange}
                  required
                  placeholder="Your name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleFormChange}
                  required
                  placeholder="Your email"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleFormChange}
                  required
                  rows="5"
                  placeholder="Your message"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                ></textarea>
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Terms & Protection Page (accessed via link in footer) */}
        {currentPage === 'terms' && (
          <div className="max-w-4xl mx-auto space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Booking Protection & Terms</h1>
            </div>

            <div className="bg-blue-50 rounded-xl p-8 border border-blue-200 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Financial Protection</h2>
              <p className="text-gray-700 mb-4">Hevara Travel is an independent travel agent trading on behalf of <strong>InteleTravel Ltd</strong>, a Member of ABTA (membership number available on request). Many of the holidays and travel services we sell are financially protected.</p>
              <p className="text-gray-700 mb-4">Where you buy a package that includes a flight, it will be <strong>ATOL protected</strong> and you will receive an ATOL Certificate confirming what is covered and who is responsible for delivering it. The protection that applies depends on the travel arrangements you book — we will always confirm in writing exactly what covers your trip before you pay.</p>
              <p className="text-gray-700">For more information about ABTA and ATOL protection, visit <strong>www.abta.com</strong> or <strong>www.caa.co.uk/atol</strong>.</p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Why ATOL & ABTA Matter</h2>
              <ul className="space-y-3 text-gray-700">
                <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> <strong>Financial Protection:</strong> Protects you if your travel company fails financially</li>
                <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> <strong>ATOL Certificate:</strong> You receive proof of what's covered and who delivers each part</li>
                <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> <strong>Dispute Resolution:</strong> Access to ABTA's arbitration service if issues arise</li>
                <li className="flex gap-3"><span className="text-blue-600 font-bold">✓</span> <strong>Code of Conduct:</strong> Assurance that we follow strict industry standards</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Booking with Us</h2>
              <p className="text-gray-700 mb-4">When you book through Hevara Travel, you're benefiting from:</p>
              <ul className="space-y-2 text-gray-700">
                <li>• Expert guidance from experienced travel professionals</li>
                <li>• Access to a wide range of trusted tour operators and accommodation providers</li>
                <li>• Competitive pricing negotiated on your behalf</li>
                <li>• Support and assistance throughout your holiday</li>
                <li>• Financial protection through InteleTravel's ABTA and ATOL licences</li>
              </ul>
            </div>

            <div className="bg-gray-50 rounded-xl p-8 border border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Questions?</h2>
              <p className="text-gray-700 mb-4">If you have any questions about your booking protection or how ATOL/ABTA works, please don't hesitate to contact us.</p>
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <Phone size={18} className="text-blue-600" />
                  <a href="tel:+447741326960" className="text-blue-600 hover:text-blue-700 font-semibold">+44 7741 326960</a>
                </div>
                <div className="flex items-center gap-2">
                  <Mail size={18} className="text-blue-600" />
                  <a href="mailto:hello@hevaratravel.co.uk" className="text-blue-600 hover:text-blue-700 font-semibold">hello@hevaratravel.co.uk</a>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-teal-400 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">H</span>
                </div>
                <span className="font-semibold text-white">Hevara Travel</span>
              </div>
              <p className="text-sm">Explore • Dream • Discover</p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                {navigationItems.map(item => (
                  <li key={item.id}>
                    <button
                      onClick={() => setCurrentPage(item.id)}
                      className="hover:text-white transition"
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="tel:+447741326960" className="hover:text-white transition">
                    +44 7741 326960
                  </a>
                </li>
                <li>
                  <a href="mailto:hello@hevaratravel.co.uk" className="hover:text-white transition">
                    hello@hevaratravel.co.uk
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Follow Us</h4>
              <div className="flex gap-4 text-sm">
                <a href="https://instagram.com/hevaratravel" className="hover:text-white transition">Instagram</a>
                <a href="https://facebook.com/hevaratravel" className="hover:text-white transition">Facebook</a>
                <a href="https://twitter.com/hevaratravel" className="hover:text-white transition">X</a>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8">
            <div className="bg-blue-900 bg-opacity-30 rounded-lg p-6 mb-6">
              <p className="text-sm mb-2"><strong>Your Financial Protection</strong></p>
              <p className="text-sm">Hevara Travel is an independent travel agent trading on behalf of InteleTravel Ltd, a Member of ABTA. Many of the holidays and travel services we sell are financially protected. Where you buy a package that includes a flight, it will be ATOL protected by the ATOL holder, who will issue your ATOL Certificate confirming what is covered and who is responsible for delivering it.</p>
              <button
                onClick={() => setCurrentPage('terms')}
                className="text-sm text-blue-400 hover:text-blue-300 mt-3"
              >
                Learn more about booking protection →
              </button>
            </div>

            <div className="flex flex-col md:flex-row justify-between items-center text-sm">
              <p>© 2026 Hevara Travel. All rights reserved.</p>
              <div className="flex gap-6 mt-4 md:mt-0">
                <button onClick={() => setCurrentPage('terms')} className="hover:text-white transition">Booking Protection</button>
                <a href="#" className="hover:text-white transition">Privacy Policy</a>
                <a href="#" className="hover:text-white transition">Terms of Service</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
